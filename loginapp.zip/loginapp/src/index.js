import React from 'react'
import ReactDom from 'react-dom'
import Routing from './Routing'
ReactDom.render(<Routing/>,document.getElementById('root'))