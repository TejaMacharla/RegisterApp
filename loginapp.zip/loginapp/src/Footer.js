import React from 'react'
const Footer=()=>{
    return(
        <div>
            <hr/>
            <center><h2>&copy;tejamacharla1997 </h2></center>
            
            
        </div>
        
    )
}
export default Footer;